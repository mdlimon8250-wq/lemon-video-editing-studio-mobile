# 🍋 Lemon Video Editing Studio (Mobile / Android)
## GitHub দিয়ে APK বানানো
1. নতুন repository খুলুন (নাম: lemon-video-editing-studio-mobile)।
2. জিপ এক্সট্র্যাক্ট করে ভেতরের সব ফাইল ও ফোল্ডার (.github সহ) আপলোড করুন → Commit।
3. Actions ট্যাব → "Build Android APK" শেষ হলে Artifacts থেকে LemonVideoEditingStudio-APK নামান।
4. APK ইনস্টল করার সময় "Unknown sources" অনুমতি দিন।
